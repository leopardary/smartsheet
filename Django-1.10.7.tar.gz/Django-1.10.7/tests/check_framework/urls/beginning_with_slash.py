from django.conf.urls import url

urlpatterns = [
    url(r'/starting-with-slash/$', lambda x: x),
]
